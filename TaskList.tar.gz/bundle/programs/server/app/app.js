var require = meteorInstall({"server":{"main.js":["meteor/meteor",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////
//                                                                          //
// server/main.js                                                           //
//                                                                          //
//////////////////////////////////////////////////////////////////////////////
                                                                            //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                            //
Working = new Mongo.Collection('data');                                     // 3
                                                                            //
Meteor.methods({                                                            // 5
  addTask: function addTask(task) {                                         // 6
    Working.insert({                                                        // 7
      title: task,                                                          // 8
      created: new Date()                                                   // 9
    });                                                                     // 7
  },                                                                        // 11
  removeTask: function removeTask(id) {                                     // 12
    Working.remove(id);                                                     // 13
  },                                                                        // 14
  updateTask: function updateTask(id, checked) {                            // 15
    Working.update(id, { $set: { checked: checked } });                     // 16
  }                                                                         // 17
});                                                                         // 5
Meteor.startup(function () {});                                             // 19
//////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
